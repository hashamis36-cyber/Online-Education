# Online Education — Live, Recorded & Payment v6

This development stage adds the application structure for:
- Live class schedule and Join Class buttons
- Recorded lesson catalog with protected-content placeholders
- International payment checkout placeholder
- Student payment history/status UI
- Admin controls for class/video/payment records

Production integrations still required:
- Deploy the backend over HTTPS
- Connect a real database
- Configure a live-class provider (Zoom/Google Meet/Jitsi or custom WebRTC)
- Upload videos to secure storage/CDN with access control
- Connect a supported payment provider and server-side webhook verification
- Add receipts/refunds and currency handling
- Add notifications and audit logs
- Complete Android/iOS packaging and store compliance

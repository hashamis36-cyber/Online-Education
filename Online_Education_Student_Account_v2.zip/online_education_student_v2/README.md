# Online Education — Student Account v2

Second practical prototype. It adds a student account/dashboard with local demo storage.

Included:
- Student registration on the device
- Student ID generation
- Student course selection
- Student dashboard
- Attendance preview
- Fee status preview
- My lessons preview
- Class schedule placeholder
- Recorded lessons placeholder
- Certificates placeholder
- Logout
- Existing Home/Courses/Admission/Live/Payment sections

Important: this is a prototype. Real accounts require a secure backend/database and authentication; real payment, live classes, video hosting and admin controls are next production integrations.

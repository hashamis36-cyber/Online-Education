# Online Education — Backend & Secure Auth v4

This is the fourth development stage: a real API foundation instead of browser-only demo storage.

## Included
- Node.js + Express API
- Student registration
- Login with bcrypt password hashing
- JWT authentication
- Admin-only student management
- Add/delete students
- Announcements
- Health endpoint
- JSON database for local development

## Run locally
1. Install Node.js 18+.
2. In this folder run `npm install`.
3. Set a strong environment variable: `JWT_SECRET`.
4. Run `npm start`.
5. Open `http://localhost:3000`.

## Important
This is a development foundation, not a deployed production service. Before public/international launch, move data to a managed database, use HTTPS, set a strong secret, add rate limiting, email verification/password reset, backups, audit logs, role permissions, secure file/video storage, payment verification, and privacy/terms pages.

import express from "express";
import cors from "cors";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import crypto from "crypto";

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "CHANGE_THIS_IN_PRODUCTION";
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB = path.join(__dirname, "data.json");

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

function load(){ if(!fs.existsSync(DB)) fs.writeFileSync(DB, JSON.stringify({users:[],students:[],announcements:[]},null,2)); return JSON.parse(fs.readFileSync(DB)); }
function save(db){ fs.writeFileSync(DB, JSON.stringify(db,null,2)); }

function auth(req,res,next){
  const h=req.headers.authorization||"";
  if(!h.startsWith("Bearer ")) return res.status(401).json({error:"Authentication required"});
  try{ req.user=jwt.verify(h.slice(7),JWT_SECRET); next(); }catch{ return res.status(401).json({error:"Invalid or expired token"}); }
}
function admin(req,res,next){ if(req.user.role!=="admin") return res.status(403).json({error:"Admin only"}); next(); }

app.get("/api/health",(req,res)=>res.json({ok:true,service:"Online Education API"}));

app.post("/api/auth/register", async (req,res)=>{
  const {name,email,password}=req.body;
  if(!name||!email||!password||password.length<8) return res.status(400).json({error:"Name, email and password (8+ chars) are required"});
  const db=load(); if(db.users.some(u=>u.email.toLowerCase()===email.toLowerCase())) return res.status(409).json({error:"Email already registered"});
  const user={id:crypto.randomUUID(),name,email:email.toLowerCase(),password:await bcrypt.hash(password,12),role:"student",createdAt:new Date().toISOString()};
  db.users.push(user); save(db);
  res.status(201).json({id:user.id,name:user.name,email:user.email,role:user.role});
});

app.post("/api/auth/login", async (req,res)=>{
  const {email,password}=req.body; const db=load(); const user=db.users.find(u=>u.email===String(email||"").toLowerCase());
  if(!user || !(await bcrypt.compare(password||"",user.password))) return res.status(401).json({error:"Invalid email or password"});
  const token=jwt.sign({sub:user.id,role:user.role,name:user.name},JWT_SECRET,{expiresIn:"7d"});
  res.json({token,user:{id:user.id,name:user.name,email:user.email,role:user.role}});
});

app.get("/api/me",auth,(req,res)=>res.json(req.user));

app.get("/api/students",auth,admin,(req,res)=>{
  const db=load(); res.json(db.students.map(({password,...s})=>s));
});

app.post("/api/students",auth,admin,(req,res)=>{
  const {name,phone,country,course,feeStatus="Pending"}=req.body;
  if(!name||!course) return res.status(400).json({error:"Name and course are required"});
  const db=load(); const student={id:"ST"+Math.floor(100000+Math.random()*900000),name,phone,country,course,feeStatus,attendance:0,createdAt:new Date().toISOString()};
  db.students.push(student); save(db); res.status(201).json(student);
});

app.delete("/api/students/:id",auth,admin,(req,res)=>{
  const db=load(); const before=db.students.length; db.students=db.students.filter(s=>s.id!==req.params.id);
  if(before===db.students.length) return res.status(404).json({error:"Student not found"}); save(db); res.json({ok:true});
});

app.post("/api/announcements",auth,admin,(req,res)=>{
  if(!req.body.text) return res.status(400).json({error:"Announcement text required"});
  const db=load(); const item={id:crypto.randomUUID(),text:req.body.text,createdAt:new Date().toISOString()};
  db.announcements.unshift(item); save(db); res.status(201).json(item);
});
app.get("/api/announcements",(req,res)=>res.json(load().announcements));

app.listen(PORT,()=>console.log(`Online Education API running on http://localhost:${PORT}`));

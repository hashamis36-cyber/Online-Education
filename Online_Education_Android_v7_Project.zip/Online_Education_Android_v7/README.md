# Online Education v7 — Android Project

This is an Android WebView wrapper around the current v7 web UI. It is a source project prepared for Android Studio.

## Build
Open this folder in Android Studio, let Gradle sync, then Build > Build APK(s).

## Important
The current HTML calls /api endpoints. For real login, live classes, videos and payments, deploy the backend and change the API base URL in the HTML from location.origin + "/api" to your HTTPS production API URL. A real payment gateway and live-class provider must be connected before production use.

Online Education v7 — PWA package

This package adds a web manifest and service worker so the app can be prepared for PWABuilder.

IMPORTANT:
- The app must be hosted at a public HTTPS URL.
- The backend API must also be hosted and reachable for login/live/video/payment features.
- Then open https://www.pwabuilder.com/ and enter the public HTTPS URL.
- Choose Android packaging to generate the Android package without Android Studio.

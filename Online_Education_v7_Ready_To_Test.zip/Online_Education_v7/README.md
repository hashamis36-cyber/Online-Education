# Online Education v7

A working browser/PWA prototype assembled from the uploaded Online Education v2–v6 stages.

Included:
- Student registration/login (local demo storage)
- Student dashboard
- Admin panel
- Announcements
- Live class records
- Recorded lesson records
- Payment request/history structure
- PWA manifest

## Run
Open `index.html` in a browser. For PWA install/testing, serve this folder over HTTPS (or localhost).

## Important for Play Store
This is a functional prototype/source package, not a signed Android AAB. Before public release, connect a production backend/database, real Live provider, secure video hosting, real payment gateway/webhooks, HTTPS, privacy policy, and Android packaging/signing.

Admin panel: `admin.html`
Demo admin note: this prototype has no real authentication on the admin page; replace it with server-side authentication before production.

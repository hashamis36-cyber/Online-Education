const key='oe_admin_students';let students=JSON.parse(localStorage.getItem(key)||'[]');
if(!students.length){students=[
{name:'Demo Student',course:'Tajweed Quran',phone:'+92 300 0000000',attendance:100,fee:'Paid'},
{name:'New Applicant',course:'Nazra Quran',phone:'+92 311 0000000',attendance:92,fee:'Pending'}];save();}
function save(){localStorage.setItem(key,JSON.stringify(students));}
function render(){const q=document.getElementById('search').value.toLowerCase();let list=students.filter(s=>(s.name+s.course+s.phone).toLowerCase().includes(q));document.getElementById('students').innerHTML=list.map((s,i)=>`<tr><td><b>${s.name}</b></td><td>${s.course}</td><td>${s.phone}</td><td>${s.attendance}%</td><td><span class="pill ${s.fee.toLowerCase()}">${s.fee}</span></td><td><button class="remove" onclick="removeStudent(${students.indexOf(s)})">Delete</button></td></tr>`).join('');document.getElementById('studentCount').textContent=students.length;document.getElementById('paidCount').textContent=students.filter(s=>s.fee==='Paid').length;document.getElementById('pendingCount').textContent=students.filter(s=>s.fee==='Pending').length;}
function openModal(){document.getElementById('modal').classList.remove('hidden')}function closeModal(){document.getElementById('modal').classList.add('hidden')}
function addStudent(e){e.preventDefault();students.push({name:document.getElementById('name').value,phone:document.getElementById('phone').value,course:document.getElementById('course').value,fee:document.getElementById('fee').value,attendance:0});save();render();e.target.reset();closeModal();}
function removeStudent(i){if(confirm('Delete this student?')){students.splice(i,1);save();render();}}
function saveAnnouncement(){localStorage.setItem('oe_announcement',document.getElementById('announcement').value);document.getElementById('annResult').textContent='Announcement saved.';}
function logout(){alert('Admin logout will be connected to secure authentication in the production version.');}
render();
function showMsg(text){const t=document.getElementById("toast");t.textContent=text;t.style.display="block";setTimeout(()=>t.style.display="none",3000)}
document.getElementById("admissionForm").addEventListener("submit",function(e){e.preventDefault();const data=Object.fromEntries(new FormData(this));const list=JSON.parse(localStorage.getItem("admissions")||"[]");list.push({...data,date:new Date().toISOString()});localStorage.setItem("admissions",JSON.stringify(list));this.reset();showMsg("ستاسو د داخلې معلومات په دې وسیله کې ثبت شول.")});
if("serviceWorker" in navigator) navigator.serviceWorker.register("sw.js").catch(()=>{});
document.getElementById("langBtn").onclick=()=>showMsg("ژبې: پښتو، اردو او English — د بشپړ ژبې سیستم به په راتلونکي پړاو کې فعال شي.");

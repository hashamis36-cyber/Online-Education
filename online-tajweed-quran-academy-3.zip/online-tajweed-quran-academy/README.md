# Online Tajweed Quran Academy

د Online Tajweed Quran Academy لومړنۍ بشپړه ویب/PWA نسخه.

## GitHub ته پورته کول
ټول فایلونه د repository په اصلي (root) فولډر کې پورته کړئ:
- index.html
- style.css
- app.js
- manifest.json
- sw.js
- README.md

بیا په GitHub کې **Settings → Pages** ته لاړ شئ، Source د **Deploy from a branch** وټاکئ، Branch = `main` او Folder = `/ (root)`، بیا Save وکړئ.

## مهم
دا نسخه د مخ (frontend) عملي نمونه ده. د حقیقي Student Login، Admin Panel، Live Class، Database او Online Payment لپاره backend/اصلي خدماتو ته اړتیا ده. Play Store ته د خپرولو لپاره وروسته د Android/AAB build هم جوړول کېږي.

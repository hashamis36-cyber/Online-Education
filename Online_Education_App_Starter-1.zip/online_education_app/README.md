# Online Education — Starter App

This is the first working mobile-friendly/PWA prototype for the Online Education Quran learning platform.

## Included
- Home dashboard
- Courses
- Online admission form
- Live classes placeholder
- Recorded lessons placeholder
- Fee payment placeholder
- Language switcher
- Student-facing navigation
- Mobile responsive design

## Next production integrations
1. Real student accounts and database
2. Admin dashboard
3. Live class provider (Zoom/Google Meet/Jitsi)
4. Video storage and protected recorded lessons
5. International payment gateway
6. Push notifications
7. Email/WhatsApp notifications
8. Android APK/AAB and iOS build
9. Privacy policy, terms, and store assets

The current payment, live-class, and account functions are intentionally placeholders until the required accounts and credentials are supplied.

# Online Education — Connected Student + Admin v5

This stage connects the student and admin web interfaces to the v4 backend API.

## Files
- `student_app.html`: student registration/login and dashboard
- `admin_app.html`: admin login, student management and announcements
- `backend/` is represented by the v4 package; copy the backend files beside these pages or deploy them to a server.

## API URL
Both pages default to `http://localhost:3000/api`. To use a deployed server, open browser devtools and set:
`localStorage.setItem("OE_API","https://YOUR-DOMAIN/api")`
then reload.

## Important
A real production launch still needs a deployed HTTPS backend, managed database, admin account provisioning, domain, backups, rate limiting, email verification/password reset, payment provider, video hosting/access control, live-class provider, privacy policy and app-store packaging.
